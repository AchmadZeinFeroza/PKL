<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-culture icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>SPJB & Penunjukan
                    <div class="page-title-subheading">Surat
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
            <div class="card-body">
                
                <div class="app-header-left">
                    <div class="search-wrapper">
                        <div class="input-holder">
                            <input type="text" class="search-input" placeholder="Type to search">
                            <button class="search-icon"><span></span></button>
                        </div>
                        <button class="close"></button>
                    </div>
                    <br>
                  <table class="table table-hover">
                    <thead class="thead-light">
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Kios</th>
                        <th scope="col">SPJB</th>
                        <th scope="col">Penunjukan</th>
                      </tr>
                    </thead>
                    <tbody id="myTable">
                        <?php
                         $i = 1;   
                        ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <tr>
                      <td scope="row"><?php echo e($i); ?></td>
                      <td><?php echo e($kios->nama_kios); ?></td>
                      <td>
                        <div class="btn-group">
                            <form action="<?php echo e(route('letter.update' , $kios->id_kios)); ?>" method="post">
                                <?php echo e(csrf_field()); ?><?php echo e(method_field('PATCH')); ?>

                                <input type="date" class="form-control" name="tanggal">
                                <button type="submit" class="btn btn-rounded btn-secondary"> Cetak</button>
                            </form>
                      </div>
                    </td>
                    <td>
                        <div class="btn-group">
                            <form action="<?php echo e(route('penunjukan' , $kios->id_kios)); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-rounded btn-secondary"> Cetak</button>
                            </form>
                        </div>
                    </td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($data->links()); ?>	
                </table>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                    Tambah
                </button>
            </div>
            <?php $__env->stopSection(); ?>
              <!-- Modal Tambah Kios -->
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
              aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                      <form action="<?php echo e(route('import.kios')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                              <input type="file" name="kios">
                      </div>
                      <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Tambah</button>
                      </div>
                    </form>
                  </div>
              </div>
          </div>
            <?php $__env->startSection('script'); ?>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
            <script>
                $(document).ready(function(){
                  $(".search-input").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function() {
                      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                  });
                });
            </script>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views/admin/pembuatan-surat.blade.php ENDPATH**/ ?>