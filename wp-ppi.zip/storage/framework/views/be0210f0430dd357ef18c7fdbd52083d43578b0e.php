<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?> ">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Surat Pembuatan SPJB
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style>
    .font-header{
      font-family: Arial, Helvetica, sans-serif;
      font-weight: bold;
      font-size: 15pt;
    }
    .font-content{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 13.5pt;
    }
    .font-content-footer-2{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11.5pt;
    }
    .font-content-footer{
      font-family: 'Courier New', Courier, monospace;
      font-size: 11pt;
    }
    .font-content-2{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 13.5pt;
      font-weight: bold;
    }
    .garis-header{
      color:black;
    }
    hr{
      height: 0.5px;
      background-color: black;
    }
    p{
      margin:0;
    }
    .left-6{
      margin-left: -6%;
    }
    .left-4{
      margin-left: -4%;
    }
    .left-1{
      margin-left: -1%;
    }
    .top6{
      margin-top: 6%;
    }
  </style>
</head>

<body>
       
    
    <?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('script'); ?>    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views/layouts/surat.blade.php ENDPATH**/ ?>