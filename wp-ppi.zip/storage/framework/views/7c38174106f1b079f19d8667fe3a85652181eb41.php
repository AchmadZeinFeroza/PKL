<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-culture icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>Pesan
                    <div class="page-title-subheading">Cabang Jember
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <ul class="list-group">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item p-3" data-toggle="modal" data-target="#exampleModalCenter<?php echo e($pesan->id_pesan); ?>"><i class="fas fa-envelope text-info mx-5 "></i><?php echo e($pesan->email); ?><span class="d-flex justify-content-end"><small><?php echo e($pesan->created_at); ?></small></span>
                  </li>                          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
        </div>
    </div>
    
    <?php $__env->stopSection(); ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade " id="exampleModalCenter<?php echo e($pesan->id_pesan); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($pesan->nama); ?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
             <?php echo e($pesan->pesan); ?>

            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('hapus-pesan' , $pesan->id_pesan)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger" >Hapus</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </form>
                 <button type="button" class="btn btn-success">Balas</button>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->startSection('script'); ?>
    <script>
        $( ".list-group-item" ).mouseover(function() {
             $(this).addClass( "active" );
        });
        $( ".list-group-item" ).mouseout(function() {
             $(this).removeClass( "active" );
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views/admin/pesan.blade.php ENDPATH**/ ?>