<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-culture icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>Daftar Kecamatan
                    <div class="page-title-subheading">Cabang Jember
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($kio); ?></h5>
                <table id="dt" class="mb-0 table table-hover" id="usertable">
                    <thead>
                        <tr>
                            <th>Nama Kios</th>
                            <th>Pemilik</th>
                            <th>Alamat</th>
                            <th>Kecamatan</th>
                            <th>Desa</th>
                            <th>No Telpon</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($kios->nama_kios); ?></td>
                            <td><?php echo e($kios->pemilik); ?></td>
                            <td><?php echo e($kios->alamat); ?></td>
                            <td><?php echo e($kios->kecamatan); ?></td>
                            <td><?php echo e($kios->desa); ?></td>
                            <td><?php echo e($kios->no_telpon); ?></td>
                            <td>
                                <form action="<?php echo e(route('hapus' , $kios->id_kios)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

    <script>
        $('#dt').DataTable();
    </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views/admin/detail-kecamatan.blade.php ENDPATH**/ ?>