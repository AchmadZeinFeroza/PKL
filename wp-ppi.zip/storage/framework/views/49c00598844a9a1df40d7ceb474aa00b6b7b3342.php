<!--

=========================================================
* Now UI Kit - v1.3.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-kit
* Copyright 2019 Creative Tim (http://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/now-ui-kit/blob/master/LICENSE.md)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?> ">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Surat Pembuatan SPJB
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />>
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?> " rel="stylesheet" />
  <style>
    .font-header{
      font-family: Arial, Helvetica, sans-serif;
      font-weight: bold;
      font-size: 18pt;
    }
    .font-content{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 16.5pt;
    }
    .font-content-footer-2{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 14.5pt;
    }
    .font-content-footer{
      font-family: 'Courier New', Courier, monospace;
      font-size: 14pt;
    }
    .font-content-2{
      font-family: Arial, Helvetica, sans-serif;
      font-size: 16.5pt;
      font-weight: bold;
    }
    .garis-header{
      color:black;
    }
    hr{
      height: 0.5px;
      background-color: black;
    }
    p{
      margin:0;
    }
  </style>
</head>

<body>
    <div class="container">
      <div class="row mt-5">
        <div class="col-md-12">
          <div class="header mx-auto col-md-8 text-center">
            <img src="<?php echo e(asset('images/Picture1.png')); ?>">
              <p class="mt-4 font-header">PERJANJIAN</p>
              <p class="font-header">antara</p>
              <p class="font-header">PT. PERUSAHAAN PERDAGANGAN INDONESIA (Persero)</p>
              <p class="font-header">dengan</p>
              <p class="font-header">TANI MANDIRI TK</p>
              <p class="font-header">tentang</p>
              <p class="font-header">JUAL BELI PUPUK BERSUBSIDI PT PETROKIMIA GRESIK</p>
          </div>

          <div class="col-md-11 mx-auto text-center">
            <hr class="mt-5 mb-4">
            <p class="font-content"> Nomor : 69/PPI/Sub Cab-Jbr/SPJB/PKG-Jbr/XII/2019</p>
          </div>
          <div class="col-md-11 mx-auto mt-4 form-group row">
            <p class="font-content">Pada hari ini, Jumat, tanggal dua puluh, bulan Desember, tahun dua ribu Sembilan belas
              (20-12-2019), kami yang bertanda tangan di bawah ini :
            </p>
            <div class="mt-3 col-md-4 mr-5 inline">
              <span class="font-content-2">1. IMAM SUPINGI </span>
            </div>
            <div class="mt-3"><span class="font-content-2">:</span></div>
            <div class="col-md-7 mt-3">
              <p class="font-content text-justify">Pimpinan PT. Perusahaan Perdagangan Indonesia (Persero), dalam hal ini bertindak untuk dan atas nama PT. Perusahaan Perdagangan Indonesia (Persero), berkedudukan di Jl. Rajawali No. 54 Surabaya.
              selaku Distributor PT Petrokimia Gresik Berdasarkan Surat Penunjukan Nomor : 7132/B/SA.04.02/24/DR/2019
              Selanjutnya disebut “PIHAK PERTAMA”.
              </p>
            </div>
          </div>

          <div class="col-md-11 mx-auto mt-4 form-group row">
            <div class="mt-3 col-md-4 mr-5 inline">
              <span class="font-content-2">2. LIEM DJIENG HWIE </span>
            </div>
            <div class="mt-3"><span class="font-content-2">:</span></div>
            <div class="col-md-7 mt-3">
              <p class="font-content text-justify">Pemilik / Penanggung Jawab Tani Mandiri TK  dalam hal ini bertindak untuk dan atas nama Tani Mandiri TK   berkedudukan di Jalan Budi Utomo No.99  Desa Mumbulsari Kecamatan Mumbulsari Kabupaten Jember
                Selanjutnya disebut “PIHAK KEDUA”.                
              </p>
            </div>
          </div>

          <div class="col-md-11 mx-auto mt-4 form-group row">
            <p class="font-content">
              PIHAK PERTAMA dan PIHAK KEDUA secara bersama-sama, selanjutnya disebut “PARA PIHAK”, dan secara sendiri-sendiri disebut “PIHAK”.
            </p>
            <div class="mt-2">
              <p class="font-content">
                PARA PIHAK terlebih dahulu menerangkan hal-hal sebagai berikut :
              </p>
            </div>
          </div>

          <div class="col-md-11 mx-auto form-group row ">
            <div class="col-md-1">
              <p class="font-content">a.</p>
            </div>
            <div class="col-md-11 pr-5">
              <p class="font-content text-justify" style="margin-left:-6%;">bahwa PIHAK PERTAMA selaku Distributor PT Petrokimia Gresik bermaksud akan menyalurkan pupuk bersubsidi PT Petrokimia Gresik yang dikuasainya, berdasarkan surat penunjukan distributor Nomor : 7132/B/SA.04.02/24/DR/2019 dan Perjanjian Jual Beli Nomor : 2081/B/HK.01.02/24/SP/2019;
              </p>
            </div>
          </div>
          
          <div class="col-md-11 mx-auto form-group row ">
            <div class="col-md-1">
              <p class="font-content">b.</p>
            </div>
            <div class="col-md-11 pr-5">
              <p class="font-content text-justify" style="margin-left:-6%;">
                bahwa PIHAK KEDUA adalah Pengecer PIHAK PERTAMA sebagaimana Penunjukan Pengecer Pupuk Bersubsidi PT Petrokimia Gresik Nomor : 69/PPI/Sub Cab-Jbr/SPJB/PKG-
              </p>
            </div>
          </div>

          <footer>
            <div class="col-md-11 mx-auto form-group row">
              <div class="col-md-4" style="margin-left:-1%; margin-top:6%;">
                <p class="font-content-footer-2">
                  PIHAK PERTAMA : .... / ....
                </p>
              </div>
              <div class="col-md-5 text-center mt-4" style="margin-left:-4%">
                <p class="font-content">
                  Halaman 1 dari 11
                </p>
                <p class="font-content-footer mt-4">
                  SPJB Distributor dengan Pengecer
                </p>
              </div>
              <div class="col-md-4 text-center"  style="margin-left:-4%;  margin-top:6%;">
                <p class="font-content-footer-2">
                  PIHAK KEDUA : .... / ....
                </p>
              </div>
            </div>
          </footer>
          
        </div>
      </div>
    </div>

  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('js/core/jquery.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/core/bootstrap.min.js')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views//spjb.blade.php ENDPATH**/ ?>