<!-- Begin Page Content -->


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-culture icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>Daftar Admin
                    <div class="page-title-subheading">Cabang Jember
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-sm-12 mx-auto">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
        <div class="main-card mb-3 card py-5 ">
            <table class="mb-0 table table-striped ">
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->id % 2 == 0): ?>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
                    <tr>
                        <td class="px-py-5 d-flex justify-content-end mr-5">
                            <img
                                src="<?php echo e($user->getAvatar()); ?>" class="rounded-circle " width="150px"></td>
                        <td>
                            <h5><?php echo e($user->name); ?></h5>
                            <p><?php echo e($user->role); ?></p>
                            <button  type="button" class="mb-2 mr-2 btn btn-alternate button-detail"
                            data-toggle="modal" data-target="#detail-profil"  data-id='<?php echo e($user->id); ?>'>
                                Detail
                            </button>
                        </td>

                    </tr>
                    <?php elseif($user->id % 2 == 1): ?>
                    <tr>
                        <td class="text-right px-5">
                            <h5><?php echo e($user->name); ?></h5>
                            <p><?php echo e($user->role); ?></p>
                            <button  type="button" class="mb-2 mr-2 btn btn-alternate button-detail"
                            data-toggle="modal" data-target="#detail-profil"  data-id='<?php echo e($user->id); ?>' >
                                Detail
                            </button>
                        </td>
                        <td class=" px-py-5 ml-5 d-flex justify-content-start "><img
                                src="<?php echo e($user->getAvatar()); ?>" class="rounded-circle" width="150px"></td>

                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 mx-auto  d-flex justify-content-center mb-5">
            <button type="button" class="btn btn-primary p-3 px-5" data-toggle="modal" data-target="#exampleModal">
                Tambah
            </button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
<!-- Modal Tambah Admin -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('tambah-admin')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="position-relative form-group">
                        <label for="name">Nama</label>
                        <input name="name" id="name" placeholder="Masukkan Nama"  class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="email">Email</label>
                        <input name="email" id="email" placeholder="Masukkan Email" type="email" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="password">Password</label>
                        <input name="password" id="password" placeholder="Masukkan Password" type="password" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="alamat">Alamat</label>
                        <input name="alamat" id="alamat" placeholder="Masukkan alamat" type="text" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="nik">NIK</label>
                        <input name="nik" id="nik" placeholder="Masukkan nik" type="number" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="facebook">Facebook</label>
                        <input name="facebook" id="facebook" placeholder="Masukkan Facebook" type="text" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="wa">Whats App</label>
                        <input name="wa" id="wa" placeholder="Masukkan WhatsApp" type="text" class="form-control">
                    </div>
                    <div class="position-relative form-group">
                        <label for="avatar">Image</label>
                        <input name="avatar" id="avatar" type="file" class="form-control-file">
                        <small class="form-text text-muted">Pastikan Semua data terisi dengan benar</small>
                    </div>
                    <input type="hidden" name="role" value="karyawan">
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>





<div class="modal fade profil" id="detail-profil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Profil</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-5 mx-auto">
                            <img  src="<?php echo e(asset('img/default-avatar.png')); ?>" class="rounded-circle fotoprofil" width="90%"></td>
                        </div>
                      </div>
                      <hr>
                      <div class="row">
                        <form class="col-md-9 offset-md-2" method="POST" id="form-ubah" enctype="multipart/form-data" >
                            <?php echo method_field('PATCH'); ?> 
                            <?php echo csrf_field(); ?>       
                            <div class="form-group row mx-auto ">
                              <label for="name" class="col-sm-4 col-form-label text-right">Nama</label>
                              <div class="col-sm-8">
                                <input type="text" name="name" id="name" class="form-control-plaintext text-left data-name" value="">
                              </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="role" class="col-sm-4 col-form-label text-right">Posisi</label>
                                <div class="col-sm-8">
                                  <input type="text" name="role" role="role" id="role"  class="form-control-plaintext text-left data-role" value="">
                                </div>
                              </div>
                            <div class="form-group row mx-auto ">
                                <label for="email" class="col-sm-4 col-form-label text-right">Email</label>
                                <div class="col-sm-8">
                                  <input type="text" name="email" id="email" class="form-control-plaintext text-left data-email" value="">
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="nik" class="col-sm-4 col-form-label text-right">NIK</label>
                                <div class="col-sm-8">
                                  <input type="text" name="nik" id="nik" class="form-control-plaintext text-left data-nik" value="">
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="facebook" class="col-sm-4 col-form-label text-right">Facebook</label>
                                <div class="col-sm-8">
                                  <input type="text" name="facebook" id="facebook" class="form-control-plaintext text-left data-facebook" value="">
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="wa" class="col-sm-4 col-form-label text-right">Whats App</label>
                                <div class="col-sm-8">
                                  <input type="text" name="wa" id="wa" class="form-control-plaintext text-left data-wa" value="">
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="avatar" class="col-sm-4 col-form-label text-right">Foto</label>
                                <div class="col-sm-8">
                                  <input type="file" name="avatar" id="avatar" class="form-control-plaintext text-left data-avatar" value="">
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <div class="col-sm-8">
                                  <input type="hidden" name="id" id="id" class="form-control-plaintext text-left data-id" value="">
                                  
                                </div>
                            </div>
                            <div class="form-group row mx-auto ">
                                <label for="alamat" class="col-sm-4 col-form-label text-right">Alamat</label>
                                <div class="col-sm-8">
                                  <textarea class="form-control-plaintext text-left data-alamat" name="alamat" id="alamat" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning"  id="ubah">Ubah</button>
                </div>
            </form>
        </div>
    </div>
</div>


  <script>

    $('.button-detail').click(function () {
      var id = $(this).data('id');
      var urldata = "<?php echo e(url('user')); ?>" + '/' + id;
 
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });

      $.ajax({
        type: "POST",
        dataType: 'json',
        url: urldata,
        data: { '_token': $('input[name=_token]').val() },
        success: function (data) {

          if(data.avatar === ""){
            $('.fotoprofil').attr("src","<?php echo e(asset('profil')); ?>"   + '/' + 'default.png');
          }else{
            $('.fotoprofil').attr("src","<?php echo e(asset('profil')); ?>"  + '/' + data.avatar);
          }
          
          $('.data-name').val(data.name);
          $('.data-id').val(data.id);
          $('.data-email').val(data.email);
          $('.data-role').val(data.role);
          $('.data-alamat').val(data.alamat);
          $('.data-facebook').val(data.facebook);
          $('.data-wa').val(data.wa);
          $('.data-nik').val(data.nik);
          $('.data-avatar').val(data.avatar);
          var data =  $('#id').val();
          var action = "<?php echo e(url('user/ubah')); ?>" + '/' + data;
          $('#form-ubah').attr('action', action);
        }
      }).done(function (data) {
        console.log('suksess');
      });
    });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPI\PPI\resources\views/admin/daftar-admin.blade.php ENDPATH**/ ?>